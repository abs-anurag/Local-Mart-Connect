# 🛍️ LocalMart Connect

> **Real-time prices. Nearby shops. Local delivery.**

A smart web platform that shows users nearby shops with their available products and real-time prices — so you can compare and choose the cheapest option without leaving your home.

---

## 🚀 What Does It Do?

- 📍 Shows nearby shops on a map
- 💰 Displays real-time product prices from each shop
- 🔍 Lets users compare prices across multiple shops
- 🛒 Users can place orders online
- 🏍️ Local delivery system brings products to your door
- 🏪 Shopkeepers get a dashboard to manage products & prices

---

## 👥 Team — Hackronauts

| Name | Role |
|------|------|
| Shivani | Frontend & UI |
| Anurag Kumar | Backend & API |
| Debmallya Chakraborty | Database & Deployment |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML, CSS, JavaScript |
| Backend | Node.js + Express |
| Database | MongoDB |
| Maps | Google Maps API |
| Real-time | Socket.io |

---

## 📁 Project Structure

```
localmart-connect/
├── frontend/
│   └── src/
│       ├── index.html
│       ├── style.css
│       ├── app.js
│       ├── components/
│       └── pages/
├── backend/
│   ├── server.js
│   ├── routes/
│   └── models/
└── README.md
```

---

## ⚙️ How To Run

```bash
git clone https://github.com/YOUR_USERNAME/localmart-connect.git
cd localmart-connect/backend
npm install
node server.js
```
Then open `frontend/src/index.html` in browser.

---

## 💡 Problem We Are Solving

60M+ kirana shops in India have zero digital presence. Customers waste time visiting multiple shops just to compare prices. LocalMart Connect bridges this gap.

---

## 📊 Impact

- 🏪 **60M+** Kirana shops in India can go digital
- 💸 **₹50L Cr** unorganised retail market opportunity
- 📱 **82%** users prefer local shopping but lack information

---

*Made with ❤️ for Hackathon 2026*
