const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

let shops = [
  { id: 1, name: "Sharma General Store", location: "Sector 22", distance: "0.3 km", rating: 4.5 },
  { id: 2, name: "Gupta Kirana",         location: "Sector 18", distance: "0.6 km", rating: 4.2 },
  { id: 3, name: "Verma Mart",           location: "Sector 20", distance: "0.9 km", rating: 4.0 },
  { id: 4, name: "Raj Dairy",            location: "Sector 21", distance: "1.1 km", rating: 4.7 },
];

let products = [
  { id: 1, name: "Basmati Rice (1kg)", shopId: 1, price: 78,  category: "Grains" },
  { id: 2, name: "Basmati Rice (1kg)", shopId: 2, price: 72,  category: "Grains" },
  { id: 3, name: "Basmati Rice (1kg)", shopId: 3, price: 85,  category: "Grains" },
  { id: 4, name: "Amul Milk (1L)",     shopId: 1, price: 62,  category: "Dairy"  },
  { id: 5, name: "Amul Milk (1L)",     shopId: 2, price: 60,  category: "Dairy"  },
  { id: 6, name: "Amul Milk (1L)",     shopId: 4, price: 58,  category: "Dairy"  },
];

let orders = [];

app.get("/", (req, res) => {
  res.json({ message: "LocalMart Connect API", team: "Hackronauts" });
});

app.get("/api/shops", (req, res) => {
  res.json({ success: true, data: shops });
});

app.get("/api/products", (req, res) => {
  res.json({ success: true, data: products });
});

app.get("/api/compare/:productName", (req, res) => {
  const name = req.params.productName.toLowerCase();
  const result = products
    .filter(p => p.name.toLowerCase().includes(name))
    .map(p => ({ ...p, shop: shops.find(s => s.id === p.shopId) }))
    .sort((a, b) => a.price - b.price);
  res.json({ success: true, results: result });
});

app.post("/api/orders", (req, res) => {
  const order = { id: orders.length + 1, ...req.body, status: "Placed", placedAt: new Date() };
  orders.push(order);
  res.json({ success: true, order });
});

app.put("/api/products/:id/price", (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (!product) return res.status(404).json({ success: false, message: "Not found" });
  product.price = req.body.price;
  res.json({ success: true, product });
});

app.listen(PORT, () => {
  console.log("LocalMart Connect running on http://localhost:" + PORT);
});
