// ===== SAMPLE DATA (In real app, this comes from backend API) =====
const products = [
  {
    name: "Basmati Rice (1kg)",
    emoji: "🌾",
    shops: [
      { name: "Sharma General Store", price: 78, distance: "0.3 km" },
      { name: "Gupta Kirana", price: 72, distance: "0.6 km" },
      { name: "Verma Mart", price: 85, distance: "0.9 km" },
    ]
  },
  {
    name: "Amul Milk (1L)",
    emoji: "🥛",
    shops: [
      { name: "Sharma General Store", price: 62, distance: "0.3 km" },
      { name: "Gupta Kirana", price: 60, distance: "0.6 km" },
      { name: "Raj Dairy", price: 58, distance: "1.1 km" },
    ]
  },
  {
    name: "Sugar (1kg)",
    emoji: "🍚",
    shops: [
      { name: "Verma Mart", price: 45, distance: "0.9 km" },
      { name: "Sharma General Store", price: 48, distance: "0.3 km" },
      { name: "Gupta Kirana", price: 44, distance: "0.6 km" },
    ]
  },
  {
    name: "Toor Dal (500g)",
    emoji: "🫘",
    shops: [
      { name: "Gupta Kirana", price: 95, distance: "0.6 km" },
      { name: "Sharma General Store", price: 102, distance: "0.3 km" },
      { name: "Raj Dairy", price: 89, distance: "1.1 km" },
    ]
  },
  {
    name: "Bread (Large)",
    emoji: "🍞",
    shops: [
      { name: "Sharma General Store", price: 45, distance: "0.3 km" },
      { name: "Raj Dairy", price: 42, distance: "1.1 km" },
      { name: "Verma Mart", price: 50, distance: "0.9 km" },
    ]
  },
  {
    name: "Atta (5kg)",
    emoji: "🌾",
    shops: [
      { name: "Verma Mart", price: 220, distance: "0.9 km" },
      { name: "Gupta Kirana", price: 210, distance: "0.6 km" },
      { name: "Sharma General Store", price: 235, distance: "0.3 km" },
    ]
  }
];

// ===== LOAD PRODUCTS ON HOME PAGE =====
function loadProducts(data) {
  const grid = document.getElementById("productGrid");
  if (!grid) return;

  grid.innerHTML = "";

  data.forEach(product => {
    // Find the minimum price shop
    const minPrice = Math.min(...product.shops.map(s => s.price));

    let shopsHTML = product.shops
      .sort((a, b) => a.price - b.price)
      .map(shop => {
        const isBest = shop.price === minPrice;
        return `
          <div class="shop-price-row ${isBest ? 'best-price' : ''}">
            <span>${shop.name} <small style="color:#8eafc1">(${shop.distance})</small></span>
            <span class="price">₹${shop.price} ${isBest ? '<span class="best-badge">BEST</span>' : ''}</span>
          </div>
        `;
      }).join("");

    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <h3>${product.emoji} ${product.name}</h3>
      ${shopsHTML}
      <button class="order-btn" onclick="orderProduct('${product.name}', ${minPrice})">
        🛒 Order at ₹${minPrice}
      </button>
    `;
    grid.appendChild(card);
  });
}

// ===== SEARCH FUNCTION =====
function searchProduct() {
  const query = document.getElementById("searchInput").value.toLowerCase().trim();

  if (query === "") {
    loadProducts(products);
    return;
  }

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(query)
  );

  if (filtered.length === 0) {
    const grid = document.getElementById("productGrid");
    if (grid) {
      grid.innerHTML = `
        <div style="grid-column:1/-1; text-align:center; padding:40px; color:#556677;">
          <p style="font-size:40px">🔍</p>
          <p style="font-size:18px; margin-top:10px;">No results found for "<strong>${query}</strong>"</p>
          <p style="margin-top:8px;">Try searching: Rice, Milk, Sugar, Dal, Bread, Atta</p>
        </div>
      `;
    }
  } else {
    loadProducts(filtered);
  }

  // Scroll to products section
  const productsSection = document.querySelector(".products");
  if (productsSection) {
    productsSection.scrollIntoView({ behavior: "smooth" });
  }
}

// ===== ORDER FUNCTION =====
function orderProduct(name, price) {
  const overlay = document.getElementById("orderModal");
  if (overlay) {
    document.getElementById("modalProductName").textContent = name;
    document.getElementById("modalPrice").textContent = price;
    overlay.classList.add("active");
  } else {
    alert(`✅ Order placed for ${name} at ₹${price}!\n\nYour order will be delivered within 30-45 minutes.`);
  }
}

function closeModal() {
  const overlay = document.getElementById("orderModal");
  if (overlay) overlay.classList.remove("active");
}

// ===== ENTER KEY ON SEARCH =====
document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    searchInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") searchProduct();
    });
  }

  // Load all products on page load
  loadProducts(products);
});

// ===== EXPORT FOR OTHER PAGES =====
if (typeof module !== "undefined") {
  module.exports = { products };
}
